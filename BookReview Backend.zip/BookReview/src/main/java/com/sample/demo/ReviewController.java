package com.sample.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins="*")
public class ReviewController {
	@Autowired
	ReviewDao reviewDao;
	
	@PostMapping("/addReview")
	public boolean addReview(@RequestBody Reviews review) {
		return reviewDao.addReview(review);
	}
	
	@GetMapping("/getReviewByBook/{bookName}")
	public List<Reviews> getReviewByBook(@PathVariable("bookName") String bookName){
		return reviewDao.getReviewsByBook(bookName);
	}
}
